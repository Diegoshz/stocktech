<?php
// ============================================================
// StockTech — Etapa 5: Excluir categoria (categorias/excluir.php)
// Os produtos da categoria NÃO são apagados: o banco coloca
// categoria_id = NULL neles (regra ON DELETE SET NULL da Etapa 2).
// ============================================================
require_once __DIR__ . '/../includes/verificar_login.php';
require_once __DIR__ . '/../config/conexao.php';
exigir_perfil('administrador'); // só o administrador exclui

$id = (int) ($_GET['id'] ?? 0);

if ($id > 0) {
    $sql = $conexao->prepare('DELETE FROM categorias WHERE id = ?');
    $sql->execute([$id]);
}

header('Location: index.php?msg=excluida');
exit;
