<?php
// ============================================================
// StockTech — Etapa 5: Categorias (categorias/index.php)
//
// Esta única página faz 3 coisas:
//   - LISTA todas as categorias
//   - CADASTRA uma nova (formulário vazio)
//   - EDITA uma existente (quando a URL tem ?editar=ID)
// A exclusão fica no arquivo excluir.php.
// ============================================================
require_once __DIR__ . '/../includes/verificar_login.php';
require_once __DIR__ . '/../config/conexao.php';

$erro = '';
$nome = '';
$descricao = '';
$id_editar = 0;

// ---------- 1. Salvar (cadastrar ou editar) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    exigir_perfil('administrador'); // só o administrador cadastra/edita categorias
    $id_editar = (int) ($_POST['id'] ?? 0);
    $nome      = trim($_POST['nome'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');

    if ($nome === '') {
        $erro = 'O nome da categoria é obrigatório.';
    } else {
        // Verifica se já existe outra categoria com o mesmo nome.
        $busca = $conexao->prepare('SELECT id FROM categorias WHERE nome = ? AND id <> ?');
        $busca->execute([$nome, $id_editar]);

        if ($busca->fetch()) {
            $erro = 'Já existe uma categoria com esse nome.';
        } elseif ($id_editar > 0) {
            $sql = $conexao->prepare('UPDATE categorias SET nome = ?, descricao = ? WHERE id = ?');
            $sql->execute([$nome, $descricao, $id_editar]);
            header('Location: index.php?msg=editada');
            exit;
        } else {
            $sql = $conexao->prepare('INSERT INTO categorias (nome, descricao) VALUES (?, ?)');
            $sql->execute([$nome, $descricao]);
            header('Location: index.php?msg=cadastrada');
            exit;
        }
    }
}

// ---------- 2. Carregar dados para editar ----------
if (isset($_GET['editar']) && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $sql = $conexao->prepare('SELECT * FROM categorias WHERE id = ?');
    $sql->execute([(int) $_GET['editar']]);
    $categoria = $sql->fetch();
    if ($categoria) {
        $id_editar = $categoria['id'];
        $nome      = $categoria['nome'];
        $descricao = $categoria['descricao'] ?? '';
    }
}

// ---------- 3. Listar categorias (com quantos produtos cada uma tem) ----------
$categorias = $conexao->query(
    'SELECT c.id, c.nome, c.descricao, COUNT(p.id) AS total_produtos
       FROM categorias c
       LEFT JOIN produtos p ON p.categoria_id = c.id
      GROUP BY c.id
      ORDER BY c.nome'
)->fetchAll();

$mensagens = [
    'cadastrada' => 'Categoria cadastrada com sucesso!',
    'editada'    => 'Categoria atualizada com sucesso!',
    'excluida'   => 'Categoria excluída com sucesso!',
];

$titulo = 'Categorias';
require_once __DIR__ . '/../includes/topo.php';
?>

<h1>Categorias</h1>

<?php if (isset($_GET['msg'], $mensagens[$_GET['msg']])): ?>
    <div class="aviso ok"><?= $mensagens[$_GET['msg']] ?></div>
<?php endif; ?>
<?php if ($erro): ?>
    <div class="aviso erro"><?= htmlspecialchars($erro) ?></div>
<?php endif; ?>

<?php if (pode('administrador')): ?>
<div class="cartao">
    <h2><?= $id_editar ? 'Editar categoria' : 'Nova categoria' ?></h2>
    <form method="POST" action="index.php">
        <input type="hidden" name="id" value="<?= $id_editar ?>">

        <label for="nome">Nome *</label>
        <input type="text" id="nome" name="nome" maxlength="100" required
               value="<?= htmlspecialchars($nome) ?>">

        <label for="descricao">Descrição</label>
        <input type="text" id="descricao" name="descricao" maxlength="255"
               value="<?= htmlspecialchars($descricao) ?>">

        <button type="submit" class="botao">Salvar</button>
        <?php if ($id_editar): ?>
            <a href="index.php" class="botao cinza">Cancelar</a>
        <?php endif; ?>
    </form>
</div>
<?php endif; ?>

<div class="cartao">
    <h2>Categorias cadastradas (<?= count($categorias) ?>)</h2>
    <?php if (!$categorias): ?>
        <p>Nenhuma categoria cadastrada ainda.</p>
    <?php else: ?>
        <table>
            <tr><th>Nome</th><th>Descrição</th><th>Produtos</th><th>Ações</th></tr>
            <?php foreach ($categorias as $c): ?>
                <tr>
                    <td><?= htmlspecialchars($c['nome']) ?></td>
                    <td><?= htmlspecialchars($c['descricao'] ?? '') ?></td>
                    <td><?= $c['total_produtos'] ?></td>
                    <td>
                        <?php if (pode('administrador')): ?>
                        <a href="index.php?editar=<?= $c['id'] ?>" class="botao pequeno">Editar</a>
                        <a href="excluir.php?id=<?= $c['id'] ?>" class="botao pequeno vermelho"
                           onclick="return confirm('Excluir esta categoria? Os produtos dela ficarão sem categoria.');">Excluir</a>
                        <?php else: ?>—<?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/rodape.php'; ?>
