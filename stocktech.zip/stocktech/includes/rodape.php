</main>
<footer class="rodape">StockTech — Sistema de Gerenciamento de Estoque</footer>
</body>
</html>
