<?php
// ============================================================
// StockTech — Etapa 4: Proteção das páginas (includes/verificar_login.php)
//
// COMO USAR: coloque no TOPO de toda página que exige login:
//   require_once __DIR__ . '/../includes/verificar_login.php';
//
// Se o usuário não estiver logado, ele é mandado para o login.
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Se não existe o ID do usuário na sessão, ninguém fez login.
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /stocktech/usuarios/login.php');
    exit;
}

// Tempo máximo parado: 30 minutos. Depois disso, precisa logar de novo.
$tempo_limite = 30 * 60;
if (isset($_SESSION['ultimo_acesso']) && (time() - $_SESSION['ultimo_acesso']) > $tempo_limite) {
    session_unset();
    session_destroy();
    header('Location: /stocktech/usuarios/login.php?expirou=1');
    exit;
}
$_SESSION['ultimo_acesso'] = time();

// ------------------------------------------------------------
// NÍVEIS DE ACESSO (perfis)
//   administrador: pode tudo (inclusive excluir e mexer em categorias)
//   funcionario:   cadastra/edita produtos e registra entradas/saídas
//   visitante:     só consulta
// ------------------------------------------------------------

// Retorna true se o usuário logado tem um dos perfis informados.
// Exemplo: pode('administrador', 'funcionario')
function pode(...$perfis) {
    return in_array($_SESSION['usuario_perfil'] ?? '', $perfis, true);
}

// Bloqueia a página se o usuário não tiver o perfil necessário.
// Exemplo (no topo da página): exigir_perfil('administrador');
function exigir_perfil(...$perfis) {
    if (!pode(...$perfis)) {
        http_response_code(403);
        echo '<p style="font-family:Arial;padding:40px">Acesso negado: seu perfil não tem permissão para esta ação. '
           . '<a href="/stocktech/index.php">Voltar</a></p>';
        exit;
    }
}
