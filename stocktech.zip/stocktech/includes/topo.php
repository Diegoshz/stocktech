<?php
// ============================================================
// StockTech — Topo e menu (includes/topo.php)
// Use em toda página interna, DEPOIS do verificar_login.php:
//   $titulo = 'Categorias';
//   require_once __DIR__ . '/../includes/topo.php';
// ============================================================
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StockTech — <?= htmlspecialchars($titulo ?? 'Sistema') ?></title>
    <link rel="stylesheet" href="/stocktech/css/estilo.css">
</head>
<body>
<header class="topo">
    <strong>StockTech</strong>
    <nav>
        <a href="/stocktech/index.php">Início</a>
        <a href="/stocktech/produtos/index.php">Produtos</a>
        <a href="/stocktech/categorias/index.php">Categorias</a>
        <?php if (pode('administrador', 'funcionario')): ?>
        <a href="/stocktech/estoque/movimentar.php">Entrada/Saída</a>
        <?php endif; ?>
        <a href="/stocktech/estoque/historico.php">Histórico</a>
        <a href="/stocktech/usuarios/logout.php">Sair (<?= htmlspecialchars($_SESSION['usuario_nome']) ?> — <?= htmlspecialchars($_SESSION['usuario_perfil']) ?>)</a>
    </nav>
</header>
<main class="conteudo">
