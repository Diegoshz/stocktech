<?php
// ============================================================
// StockTech — Etapa 4: Sair do sistema (usuarios/logout.php)
// Apaga todos os dados da sessão e volta para o login.
// ============================================================
session_start();
session_unset();
session_destroy();
header('Location: login.php?saiu=1');
exit;
