<?php
// ============================================================
// StockTech — Etapa 4: Tela de login (usuarios/login.php)
//
// COMO FUNCIONA:
//   1. O usuário digita e-mail e senha e clica em "Entrar".
//   2. O PHP busca o e-mail no banco (com consulta preparada,
//      que protege contra SQL Injection).
//   3. password_verify() compara a senha digitada com a senha
//      criptografada do banco.
//   4. Se estiver certo, guarda os dados na SESSÃO e abre o sistema.
// ============================================================
session_start();

// Se já está logado, não precisa ver o login de novo.
if (isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

require_once __DIR__ . '/../config/conexao.php';

$erro  = '';
$email = '';

// Só processa quando o formulário foi enviado (método POST).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if ($email === '' || $senha === '') {
        $erro = 'Preencha o e-mail e a senha.';
    } else {
        // Consulta preparada: o "?" é trocado pelo e-mail com segurança.
        $sql = $conexao->prepare('SELECT id, nome, email, senha, perfil FROM usuarios WHERE email = ?');
        $sql->execute([$email]);
        $usuario = $sql->fetch();

        if ($usuario && password_verify($senha, $usuario['senha'])) {
            // Cria um novo ID de sessão (evita roubo de sessão).
            session_regenerate_id(true);

            $_SESSION['usuario_id']    = $usuario['id'];
            $_SESSION['usuario_nome']  = $usuario['nome'];
            $_SESSION['usuario_email'] = $usuario['email'];
            $_SESSION['usuario_perfil'] = $usuario['perfil'];
            $_SESSION['ultimo_acesso'] = time();

            header('Location: ../index.php');
            exit;
        } else {
            // Mensagem genérica: não conta se o erro foi no e-mail ou na senha.
            $erro = 'E-mail ou senha incorretos.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StockTech — Entrar</title>
    <style>
        body { margin: 0; min-height: 100vh; display: flex; align-items: center; justify-content: center;
               background: #f1f5f9; font-family: Arial, sans-serif; }
        .caixa { background: #fff; width: 100%; max-width: 360px; padding: 32px; border-radius: 10px;
                 box-shadow: 0 4px 16px rgba(0,0,0,.08); margin: 16px; }
        h1 { margin: 0 0 4px; color: #1e293b; }
        p.sub { margin: 0 0 24px; color: #64748b; }
        label { display: block; margin-bottom: 6px; font-weight: bold; color: #334155; }
        input { width: 100%; box-sizing: border-box; padding: 10px; margin-bottom: 16px;
                border: 1px solid #cbd5e1; border-radius: 6px; font-size: 15px; }
        button { width: 100%; padding: 12px; border: 0; border-radius: 6px; background: #0f766e;
                 color: #fff; font-size: 16px; cursor: pointer; }
        button:hover { background: #115e59; }
        .aviso { padding: 10px; border-radius: 6px; margin-bottom: 16px; font-size: 14px; }
        .erro { background: #fee2e2; color: #991b1b; }
        .ok   { background: #dcfce7; color: #166534; }
    </style>
</head>
<body>
    <div class="caixa">
        <h1>StockTech</h1>
        <p class="sub">Entre para gerenciar seu estoque</p>

        <?php if ($erro): ?>
            <div class="aviso erro"><?= htmlspecialchars($erro) ?></div>
        <?php elseif (isset($_GET['saiu'])): ?>
            <div class="aviso ok">Você saiu do sistema.</div>
        <?php elseif (isset($_GET['expirou'])): ?>
            <div class="aviso erro">Sua sessão expirou. Entre novamente.</div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" required
                   value="<?= htmlspecialchars($email) ?>">

            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" required>

            <button type="submit">Entrar</button>
        </form>
    </div>
</body>
</html>
