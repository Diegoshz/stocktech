<?php
// ============================================================
// StockTech — Teste da conexão (Etapa 3)
//
// O QUE ESTE ARQUIVO FAZ:
//   Só serve para você conferir se a conexão funcionou.
//   Abra no navegador: http://localhost/stocktech/config/testar_conexao.php
//   Ele não faz parte das telas do sistema — é só um teste.
// ============================================================

require_once __DIR__ . '/conexao.php';

echo '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 60px auto; padding: 24px; border: 1px solid #c3e6cb; background: #d4edda; color: #155724; border-radius: 8px;">';
echo '<h2 style="margin-top: 0;">✅ Conexão funcionando!</h2>';
echo '<p>O PHP conectou no banco <strong>stocktech</strong> com sucesso.</p>';

// Conta quantas linhas existem em cada tabela, para confirmar
// que o database.sql da Etapa 2 rodou direitinho.
$tabelas = ['usuarios', 'categorias', 'produtos', 'movimentacoes'];

echo '<table border="1" cellpadding="8" style="border-collapse: collapse; width: 100%;">';
echo '<tr><th>Tabela</th><th>Registros encontrados</th></tr>';

foreach ($tabelas as $tabela) {
    $total = $conexao->query("SELECT COUNT(*) AS total FROM {$tabela}")->fetch()['total'];
    echo "<tr><td>{$tabela}</td><td>{$total}</td></tr>";
}

echo '</table>';
echo '<p style="font-size: 12px;">Se aparecer 1 usuário, 3 categorias e 4 produtos, os dados de exemplo da Etapa 2 estão no lugar.</p>';
echo '</div>';
