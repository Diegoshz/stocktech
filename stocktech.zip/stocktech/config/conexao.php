<?php
// ============================================================
// StockTech — Sistema Web de Gerenciamento de Estoque
// Etapa 3: Conexão com o banco de dados (config/conexao.php)
//
// O QUE ESTE ARQUIVO FAZ:
//   Cria um objeto de conexão ($conexao) que todas as outras
//   páginas do sistema usam para conversar com o MySQL.
//
// COMO USAR (em qualquer página PHP):
//   require_once __DIR__ . '/../config/conexao.php';
//   Depois disso, a variável $conexao fica disponível.
//
// Dados usados aqui são os padrões do XAMPP:
//   - servidor (host): localhost
//   - usuário: root
//   - senha: (vazia — padrão do XAMPP)
//   - banco: stocktech (criado pelo database.sql da Etapa 2)
// ============================================================

// Dados da conexão (padrão do XAMPP — não precisa mudar nada)
$servidor = 'localhost';
$usuario  = 'root';
$senha    = '';
$banco    = 'stocktech';

try {
    // PDO é a forma moderna e segura de conectar o PHP ao MySQL.
    // O charset utf8mb4 garante que acentos (é, ç, ã) funcionem.
    $conexao = new PDO(
        "mysql:host={$servidor};dbname={$banco};charset=utf8mb4",
        $usuario,
        $senha
    );

    // Faz o PHP mostrar erros do SQL em vez de falhar em silêncio.
    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Faz as consultas devolverem array associativo: $linha['nome']
    $conexao->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

} catch (PDOException $erro) {
    // Se a conexão falhar (ex.: XAMPP desligado ou banco não criado),
    // mostra uma mensagem amigável e para a página aqui.
    die('
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 60px auto; padding: 24px; border: 1px solid #f5c6cb; background: #f8d7da; color: #721c24; border-radius: 8px;">
        <h2 style="margin-top: 0;">Não foi possível conectar ao banco de dados</h2>
        <p>Verifique estes itens:</p>
        <ol>
            <li>O <strong>XAMPP</strong> está ligado? (Apache e MySQL com botões verdes)</li>
            <li>O banco <strong>stocktech</strong> já foi criado? (Execute o <code>database.sql</code> no phpMyAdmin — Etapa 2)</li>
        </ol>
        <p style="font-size: 12px; color: #8a3a3f;">Detalhe técnico: ' . htmlspecialchars($erro->getMessage()) . '</p>
    </div>
    ');
}
