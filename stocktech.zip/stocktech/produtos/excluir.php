<?php
// ============================================================
// StockTech — Etapa 6: Excluir produto (produtos/excluir.php)
// Só o administrador pode excluir. O histórico do produto também
// é apagado pelo banco (regra ON DELETE CASCADE da Etapa 2).
// ============================================================
require_once __DIR__ . '/../includes/verificar_login.php';
require_once __DIR__ . '/../config/conexao.php';
exigir_perfil('administrador');

$id = (int) ($_GET['id'] ?? 0);
if ($id > 0) {
    $sql = $conexao->prepare('DELETE FROM produtos WHERE id = ?');
    $sql->execute([$id]);
}

header('Location: index.php?msg=excluido');
exit;
