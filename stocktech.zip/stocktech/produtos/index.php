<?php
// ============================================================
// StockTech — Etapa 6: Lista de produtos (produtos/index.php)
// Mostra todos os produtos com a situação do estoque:
//   Esgotado (quantidade 0), Estoque baixo (<= mínimo) ou Normal.
// ============================================================
require_once __DIR__ . '/../includes/verificar_login.php';
require_once __DIR__ . '/../config/conexao.php';

// ---------- Etapa 10: pesquisa e filtros ----------
// Os filtros chegam pela URL (método GET), ex.: index.php?busca=mouse&situacao=baixo
$busca     = trim($_GET['busca'] ?? '');
$categoria = $_GET['categoria'] ?? '';
$situacao  = $_GET['situacao'] ?? '';

// Montamos o WHERE aos poucos: cada filtro preenchido acrescenta uma condição.
// Os valores vão separados em $parametros (consulta preparada = seguro).
$condicoes  = [];
$parametros = [];

if ($busca !== '') {
    $condicoes[] = '(p.nome LIKE ? OR p.codigo LIKE ? OR p.marca LIKE ?)';
    $termo = "%{$busca}%";
    array_push($parametros, $termo, $termo, $termo);
}
if ($categoria === 'sem') {
    $condicoes[] = 'p.categoria_id IS NULL';
} elseif ($categoria !== '') {
    $condicoes[] = 'p.categoria_id = ?';
    $parametros[] = (int) $categoria;
}
if ($situacao === 'normal')   $condicoes[] = 'p.quantidade > p.estoque_minimo';
if ($situacao === 'baixo')    $condicoes[] = 'p.quantidade > 0 AND p.quantidade <= p.estoque_minimo';
if ($situacao === 'esgotado') $condicoes[] = 'p.quantidade = 0';

$where = $condicoes ? 'WHERE ' . implode(' AND ', $condicoes) : '';

$sql = $conexao->prepare(
    "SELECT p.*, c.nome AS categoria
       FROM produtos p
       LEFT JOIN categorias c ON c.id = p.categoria_id
       {$where}
      ORDER BY p.nome"
);
$sql->execute($parametros);
$produtos = $sql->fetchAll();

$categorias = $conexao->query('SELECT id, nome FROM categorias ORDER BY nome')->fetchAll();
$filtrando  = $busca !== '' || $categoria !== '' || $situacao !== '';

$mensagens = [
    'cadastrado' => 'Produto cadastrado com sucesso!',
    'editado'    => 'Produto atualizado com sucesso!',
    'excluido'   => 'Produto excluído com sucesso!',
];

$titulo = 'Produtos';
require_once __DIR__ . '/../includes/topo.php';
?>

<h1>Produtos</h1>

<?php if (isset($_GET['msg'], $mensagens[$_GET['msg']])): ?>
    <div class="aviso ok"><?= $mensagens[$_GET['msg']] ?></div>
<?php endif; ?>

<?php if (pode('administrador', 'funcionario')): ?>
    <p><a href="form.php" class="botao">+ Novo produto</a></p>
<?php endif; ?>

<form method="GET" action="index.php" class="cartao filtros">
    <div>
        <label for="busca">Pesquisar</label>
        <input type="text" id="busca" name="busca" placeholder="Nome, código ou marca" value="<?= htmlspecialchars($busca) ?>">
    </div>
    <div>
        <label for="categoria">Categoria</label>
        <select id="categoria" name="categoria">
            <option value="">Todas</option>
            <?php foreach ($categorias as $c): ?>
                <option value="<?= $c['id'] ?>" <?= $categoria == $c['id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['nome']) ?></option>
            <?php endforeach; ?>
            <option value="sem" <?= $categoria === 'sem' ? 'selected' : '' ?>>Sem categoria</option>
        </select>
    </div>
    <div>
        <label for="situacao">Situação</label>
        <select id="situacao" name="situacao">
            <option value="">Todas</option>
            <option value="normal"   <?= $situacao === 'normal' ? 'selected' : '' ?>>Normal</option>
            <option value="baixo"    <?= $situacao === 'baixo' ? 'selected' : '' ?>>Estoque baixo</option>
            <option value="esgotado" <?= $situacao === 'esgotado' ? 'selected' : '' ?>>Esgotado</option>
        </select>
    </div>
    <div class="filtros-botoes">
        <button type="submit" class="botao">Filtrar</button>
        <?php if ($filtrando): ?><a href="index.php" class="botao cinza">Limpar</a><?php endif; ?>
    </div>
</form>

<p><?= count($produtos) ?> produto(s) encontrado(s).</p>

<div class="cartao" style="overflow-x:auto">
    <?php if (!$produtos): ?>
        <p><?= $filtrando ? 'Nenhum produto encontrado com esses filtros.' : 'Nenhum produto cadastrado ainda.' ?></p>
    <?php else: ?>
        <table>
            <tr>
                <th>Código</th><th>Nome</th><th>Marca</th><th>Categoria</th>
                <th>Preço</th><th>Qtd.</th><th>Situação</th><th>Ações</th>
            </tr>
            <?php foreach ($produtos as $p): ?>
                <?php
                // Decide a situação do estoque deste produto
                if ($p['quantidade'] == 0) {
                    $situacao = '<span class="etiqueta esgotado">Esgotado</span>';
                } elseif ($p['quantidade'] <= $p['estoque_minimo']) {
                    $situacao = '<span class="etiqueta baixo">Estoque baixo</span>';
                } else {
                    $situacao = '<span class="etiqueta normal">Normal</span>';
                }
                ?>
                <tr>
                    <td><?= htmlspecialchars($p['codigo']) ?></td>
                    <td><?= htmlspecialchars($p['nome']) ?></td>
                    <td><?= htmlspecialchars($p['marca'] ?? '') ?></td>
                    <td><?= htmlspecialchars($p['categoria'] ?? 'Sem categoria') ?></td>
                    <td>R$ <?= number_format($p['preco'], 2, ',', '.') ?></td>
                    <td><?= $p['quantidade'] ?> (mín. <?= $p['estoque_minimo'] ?>)</td>
                    <td><?= $situacao ?></td>
                    <td>
                        <?php if (pode('administrador', 'funcionario')): ?>
                            <a href="form.php?id=<?= $p['id'] ?>" class="botao pequeno">Editar</a>
                        <?php endif; ?>
                        <?php if (pode('administrador')): ?>
                            <a href="excluir.php?id=<?= $p['id'] ?>" class="botao pequeno vermelho"
                               onclick="return confirm('Excluir este produto? O histórico de movimentações dele também será apagado.');">Excluir</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/rodape.php'; ?>
