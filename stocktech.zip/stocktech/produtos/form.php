<?php
// ============================================================
// StockTech — Etapa 6: Cadastrar / editar produto (produtos/form.php)
//   form.php        -> cadastra um produto novo
//   form.php?id=5   -> edita o produto 5
//
// IMPORTANTE: a quantidade só é informada no cadastro (estoque
// inicial). Depois disso, ela só muda por Entrada/Saída (Etapa 7),
// para que todo movimento fique registrado no histórico.
// ============================================================
require_once __DIR__ . '/../includes/verificar_login.php';
require_once __DIR__ . '/../config/conexao.php';
exigir_perfil('administrador', 'funcionario');

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$erros = [];

// Valores iniciais do formulário
$p = [
    'codigo' => '', 'nome' => '', 'marca' => '', 'descricao' => '',
    'preco' => '', 'quantidade' => 0, 'estoque_minimo' => 5, 'categoria_id' => '',
];

// Se for edição, carrega o produto do banco
if ($id > 0 && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $sql = $conexao->prepare('SELECT * FROM produtos WHERE id = ?');
    $sql->execute([$id]);
    $p = $sql->fetch();
    if (!$p) {
        header('Location: index.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pega os dados digitados
    $p['codigo']         = trim($_POST['codigo'] ?? '');
    $p['nome']           = trim($_POST['nome'] ?? '');
    $p['marca']          = trim($_POST['marca'] ?? '');
    $p['descricao']      = trim($_POST['descricao'] ?? '');
    $p['preco']          = str_replace(',', '.', trim($_POST['preco'] ?? '')); // aceita 10,50
    $p['quantidade']     = $_POST['quantidade'] ?? 0;
    $p['estoque_minimo'] = $_POST['estoque_minimo'] ?? 0;
    $p['categoria_id']   = $_POST['categoria_id'] ?? '';

    // ---------- Validações ----------
    if ($p['codigo'] === '') $erros[] = 'Informe o código do produto.';
    if ($p['nome'] === '')   $erros[] = 'Informe o nome do produto.';
    if (!is_numeric($p['preco']) || $p['preco'] < 0) $erros[] = 'Preço inválido.';
    if (!ctype_digit((string) $p['estoque_minimo'])) $erros[] = 'Estoque mínimo deve ser um número inteiro (0 ou mais).';
    if ($id === 0 && !ctype_digit((string) $p['quantidade'])) $erros[] = 'Quantidade inicial deve ser um número inteiro (0 ou mais).';

    // Código não pode repetir
    $busca = $conexao->prepare('SELECT id FROM produtos WHERE codigo = ? AND id <> ?');
    $busca->execute([$p['codigo'], $id]);
    if ($busca->fetch()) $erros[] = 'Já existe um produto com esse código.';

    if (!$erros) {
        $categoria = $p['categoria_id'] === '' ? null : (int) $p['categoria_id'];

        if ($id > 0) {
            // ---------- Editar (não mexe na quantidade) ----------
            $sql = $conexao->prepare(
                'UPDATE produtos SET codigo = ?, nome = ?, marca = ?, descricao = ?, preco = ?,
                        estoque_minimo = ?, categoria_id = ? WHERE id = ?'
            );
            $sql->execute([$p['codigo'], $p['nome'], $p['marca'], $p['descricao'], $p['preco'],
                           $p['estoque_minimo'], $categoria, $id]);
            header('Location: index.php?msg=editado');
            exit;
        }

        // ---------- Cadastrar ----------
        $sql = $conexao->prepare(
            'INSERT INTO produtos (codigo, nome, marca, descricao, preco, quantidade, estoque_minimo, categoria_id)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $sql->execute([$p['codigo'], $p['nome'], $p['marca'], $p['descricao'], $p['preco'],
                       $p['quantidade'], $p['estoque_minimo'], $categoria]);

        // Se já entrou com estoque, registra como primeira entrada no histórico
        if ($p['quantidade'] > 0) {
            $mov = $conexao->prepare(
                "INSERT INTO movimentacoes (produto_id, usuario_id, tipo, quantidade, observacao)
                 VALUES (?, ?, 'entrada', ?, 'Estoque inicial (cadastro do produto)')"
            );
            $mov->execute([$conexao->lastInsertId(), $_SESSION['usuario_id'], $p['quantidade']]);
        }
        header('Location: index.php?msg=cadastrado');
        exit;
    }
}

$categorias = $conexao->query('SELECT id, nome FROM categorias ORDER BY nome')->fetchAll();

$titulo = $id ? 'Editar produto' : 'Novo produto';
require_once __DIR__ . '/../includes/topo.php';
?>

<h1><?= $titulo ?></h1>

<?php foreach ($erros as $e): ?>
    <div class="aviso erro"><?= htmlspecialchars($e) ?></div>
<?php endforeach; ?>

<div class="cartao">
    <form method="POST" action="form.php">
        <input type="hidden" name="id" value="<?= $id ?>">

        <label for="codigo">Código *</label>
        <input type="text" id="codigo" name="codigo" maxlength="30" required value="<?= htmlspecialchars($p['codigo']) ?>">

        <label for="nome">Nome *</label>
        <input type="text" id="nome" name="nome" maxlength="150" required value="<?= htmlspecialchars($p['nome']) ?>">

        <label for="marca">Marca</label>
        <input type="text" id="marca" name="marca" maxlength="100" value="<?= htmlspecialchars($p['marca'] ?? '') ?>">

        <label for="categoria_id">Categoria</label>
        <select id="categoria_id" name="categoria_id">
            <option value="">— Sem categoria —</option>
            <?php foreach ($categorias as $c): ?>
                <option value="<?= $c['id'] ?>" <?= $c['id'] == $p['categoria_id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($c['nome']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="descricao">Descrição</label>
        <textarea id="descricao" name="descricao" rows="3"><?= htmlspecialchars($p['descricao'] ?? '') ?></textarea>

        <label for="preco">Preço (R$) *</label>
        <input type="text" id="preco" name="preco" required placeholder="Ex.: 19,90" value="<?= htmlspecialchars($p['preco']) ?>">

        <?php if ($id === 0): ?>
            <label for="quantidade">Quantidade inicial</label>
            <input type="number" id="quantidade" name="quantidade" min="0" value="<?= (int) $p['quantidade'] ?>">
        <?php else: ?>
            <p>Quantidade atual: <strong><?= (int) $p['quantidade'] ?></strong>
               — para alterar, use <a href="../estoque/movimentar.php">Entrada/Saída</a>.</p>
        <?php endif; ?>

        <label for="estoque_minimo">Estoque mínimo (alerta de estoque baixo)</label>
        <input type="number" id="estoque_minimo" name="estoque_minimo" min="0" value="<?= (int) $p['estoque_minimo'] ?>">

        <button type="submit" class="botao">Salvar</button>
        <a href="index.php" class="botao cinza">Cancelar</a>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/rodape.php'; ?>
