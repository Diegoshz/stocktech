<?php
// ============================================================
// StockTech — Etapa 7: Entradas e saídas (estoque/movimentar.php)
//
// ENTRADA: soma a quantidade ao estoque (ex.: chegou mercadoria).
// SAÍDA:   subtrai do estoque (ex.: venda). Não deixa ficar negativo.
//
// Usamos uma TRANSAÇÃO: as duas operações (registrar no histórico
// e atualizar o estoque) acontecem juntas. Se uma falhar, nenhuma
// é gravada — assim o estoque nunca fica diferente do histórico.
// ============================================================
require_once __DIR__ . '/../includes/verificar_login.php';
require_once __DIR__ . '/../config/conexao.php';
exigir_perfil('administrador', 'funcionario');

$erro = '';
$sucesso = '';
$produto_id = (int) ($_POST['produto_id'] ?? 0);
$tipo       = $_POST['tipo'] ?? 'entrada';
$quantidade = $_POST['quantidade'] ?? '';
$observacao = trim($_POST['observacao'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($produto_id <= 0) {
        $erro = 'Escolha um produto.';
    } elseif (!in_array($tipo, ['entrada', 'saida'], true)) {
        $erro = 'Tipo de movimentação inválido.';
    } elseif (!ctype_digit((string) $quantidade) || (int) $quantidade <= 0) {
        $erro = 'A quantidade deve ser um número inteiro maior que zero.';
    } else {
        $quantidade = (int) $quantidade;
        try {
            $conexao->beginTransaction();

            // FOR UPDATE "trava" o produto até o fim da transação,
            // evitando que duas saídas ao mesmo tempo passem do estoque.
            $sql = $conexao->prepare('SELECT nome, quantidade FROM produtos WHERE id = ? FOR UPDATE');
            $sql->execute([$produto_id]);
            $produto = $sql->fetch();

            if (!$produto) {
                throw new Exception('Produto não encontrado.');
            }
            if ($tipo === 'saida' && $quantidade > $produto['quantidade']) {
                throw new Exception("Estoque insuficiente: há apenas {$produto['quantidade']} unidade(s) de {$produto['nome']}.");
            }

            // 1) Registra no histórico
            $mov = $conexao->prepare(
                'INSERT INTO movimentacoes (produto_id, usuario_id, tipo, quantidade, observacao)
                 VALUES (?, ?, ?, ?, ?)'
            );
            $mov->execute([$produto_id, $_SESSION['usuario_id'], $tipo, $quantidade, $observacao ?: null]);

            // 2) Atualiza o estoque (+ na entrada, - na saída)
            $sinal = $tipo === 'entrada' ? '+' : '-';
            $upd = $conexao->prepare("UPDATE produtos SET quantidade = quantidade {$sinal} ? WHERE id = ?");
            $upd->execute([$quantidade, $produto_id]);

            $conexao->commit(); // grava tudo

            $novo = $tipo === 'entrada' ? $produto['quantidade'] + $quantidade : $produto['quantidade'] - $quantidade;
            $sucesso = ($tipo === 'entrada' ? 'Entrada' : 'Saída') . " registrada! {$produto['nome']} agora tem {$novo} unidade(s).";
            $quantidade = '';
            $observacao = '';
        } catch (Exception $e) {
            $conexao->rollBack(); // desfaz tudo
            $erro = $e->getMessage();
        }
    }
}

$produtos = $conexao->query('SELECT id, codigo, nome, quantidade FROM produtos ORDER BY nome')->fetchAll();

$titulo = 'Entrada/Saída';
require_once __DIR__ . '/../includes/topo.php';
?>

<h1>Entrada e saída de estoque</h1>

<?php if ($sucesso): ?><div class="aviso ok"><?= htmlspecialchars($sucesso) ?></div><?php endif; ?>
<?php if ($erro): ?><div class="aviso erro"><?= htmlspecialchars($erro) ?></div><?php endif; ?>

<div class="cartao">
    <form method="POST" action="movimentar.php">
        <label for="produto_id">Produto *</label>
        <select id="produto_id" name="produto_id" required>
            <option value="">— Escolha —</option>
            <?php foreach ($produtos as $p): ?>
                <option value="<?= $p['id'] ?>" <?= $p['id'] == $produto_id && $erro ? 'selected' : '' ?>>
                    <?= htmlspecialchars("{$p['codigo']} — {$p['nome']} (estoque: {$p['quantidade']})") ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Tipo *</label>
        <label style="font-weight:normal"><input type="radio" name="tipo" value="entrada" style="width:auto;margin:0 6px 0 0"
            <?= $tipo !== 'saida' ? 'checked' : '' ?>> Entrada (adicionar ao estoque)</label>
        <label style="font-weight:normal;margin-bottom:14px"><input type="radio" name="tipo" value="saida" style="width:auto;margin:0 6px 0 0"
            <?= $tipo === 'saida' ? 'checked' : '' ?>> Saída (retirar do estoque)</label>

        <label for="quantidade">Quantidade *</label>
        <input type="number" id="quantidade" name="quantidade" min="1" required value="<?= htmlspecialchars((string) $quantidade) ?>">

        <label for="observacao">Observação</label>
        <input type="text" id="observacao" name="observacao" maxlength="255" placeholder="Ex.: Nota fiscal 123, venda balcão"
               value="<?= htmlspecialchars($observacao) ?>">

        <button type="submit" class="botao">Registrar</button>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/rodape.php'; ?>
