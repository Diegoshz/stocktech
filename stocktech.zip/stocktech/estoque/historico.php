<?php
// ============================================================
// StockTech — Etapa 8: Histórico de movimentações (estoque/historico.php)
// Lista as entradas e saídas mais recentes: data, produto, tipo,
// quantidade, quem fez e observação. Etapa 10: filtros por produto, tipo e período.
// ============================================================
require_once __DIR__ . '/../includes/verificar_login.php';
require_once __DIR__ . '/../config/conexao.php';

// ---------- Etapa 10: filtros do histórico ----------
$produto_id  = (int) ($_GET['produto'] ?? 0);
$tipo        = $_GET['tipo'] ?? '';
$data_inicio = $_GET['inicio'] ?? '';
$data_fim    = $_GET['fim'] ?? '';

$condicoes  = [];
$parametros = [];

if ($produto_id > 0) {
    $condicoes[] = 'm.produto_id = ?';
    $parametros[] = $produto_id;
}
if (in_array($tipo, ['entrada', 'saida'], true)) {
    $condicoes[] = 'm.tipo = ?';
    $parametros[] = $tipo;
}
// Datas no formato AAAA-MM-DD (é o que o campo type="date" envia)
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $data_inicio)) {
    $condicoes[] = 'DATE(m.criado_em) >= ?';
    $parametros[] = $data_inicio;
}
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $data_fim)) {
    $condicoes[] = 'DATE(m.criado_em) <= ?';
    $parametros[] = $data_fim;
}

$where = $condicoes ? 'WHERE ' . implode(' AND ', $condicoes) : '';

$sql = $conexao->prepare(
    "SELECT m.*, p.codigo, p.nome AS produto, u.nome AS usuario
       FROM movimentacoes m
       JOIN produtos p ON p.id = m.produto_id
       LEFT JOIN usuarios u ON u.id = m.usuario_id
       {$where}
      ORDER BY m.criado_em DESC, m.id DESC
      LIMIT 200"
);
$sql->execute($parametros);
$movimentacoes = $sql->fetchAll();

// Totais respeitando os mesmos filtros
$sql = $conexao->prepare(
    "SELECT
        COALESCE(SUM(CASE WHEN m.tipo = 'entrada' THEN m.quantidade END), 0) AS entradas,
        COALESCE(SUM(CASE WHEN m.tipo = 'saida'   THEN m.quantidade END), 0) AS saidas
       FROM movimentacoes m
       {$where}"
);
$sql->execute($parametros);
$totais = $sql->fetch();

$produtos  = $conexao->query('SELECT id, codigo, nome FROM produtos ORDER BY nome')->fetchAll();
$filtrando = $produto_id > 0 || $tipo !== '' || $data_inicio !== '' || $data_fim !== '';

$titulo = 'Histórico';
require_once __DIR__ . '/../includes/topo.php';
?>

<h1>Histórico de movimentações</h1>

<form method="GET" action="historico.php" class="cartao filtros">
    <div>
        <label for="produto">Produto</label>
        <select id="produto" name="produto">
            <option value="">Todos</option>
            <?php foreach ($produtos as $p): ?>
                <option value="<?= $p['id'] ?>" <?= $produto_id == $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars("{$p['codigo']} — {$p['nome']}") ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="tipo">Tipo</label>
        <select id="tipo" name="tipo">
            <option value="">Todos</option>
            <option value="entrada" <?= $tipo === 'entrada' ? 'selected' : '' ?>>Entradas</option>
            <option value="saida"   <?= $tipo === 'saida' ? 'selected' : '' ?>>Saídas</option>
        </select>
    </div>
    <div>
        <label for="inicio">De</label>
        <input type="date" id="inicio" name="inicio" value="<?= htmlspecialchars($data_inicio) ?>">
    </div>
    <div>
        <label for="fim">Até</label>
        <input type="date" id="fim" name="fim" value="<?= htmlspecialchars($data_fim) ?>">
    </div>
    <div class="filtros-botoes">
        <button type="submit" class="botao">Filtrar</button>
        <?php if ($filtrando): ?><a href="historico.php" class="botao cinza">Limpar</a><?php endif; ?>
    </div>
</form>

<div class="cartao">
    Total de unidades que entraram: <strong><?= $totais['entradas'] ?></strong> &nbsp;|&nbsp;
    Total de unidades que saíram: <strong><?= $totais['saidas'] ?></strong>
</div>

<div class="cartao" style="overflow-x:auto">
    <?php if (!$movimentacoes): ?>
        <p><?= $filtrando ? 'Nenhuma movimentação encontrada com esses filtros.' : 'Nenhuma movimentação registrada ainda.' ?></p>
    <?php else: ?>
        <table>
            <tr><th>Data</th><th>Produto</th><th>Tipo</th><th>Qtd.</th><th>Usuário</th><th>Observação</th></tr>
            <?php foreach ($movimentacoes as $m): ?>
                <tr>
                    <td><?= date('d/m/Y H:i', strtotime($m['criado_em'])) ?></td>
                    <td><?= htmlspecialchars("{$m['codigo']} — {$m['produto']}") ?></td>
                    <td>
                        <?php if ($m['tipo'] === 'entrada'): ?>
                            <span class="etiqueta normal">Entrada</span>
                        <?php else: ?>
                            <span class="etiqueta esgotado">Saída</span>
                        <?php endif; ?>
                    </td>
                    <td><?= $m['tipo'] === 'entrada' ? '+' : '−' ?><?= $m['quantidade'] ?></td>
                    <td><?= htmlspecialchars($m['usuario'] ?? 'Usuário removido') ?></td>
                    <td><?= htmlspecialchars($m['observacao'] ?? '') ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <p style="color:#64748b;font-size:13px">Mostrando as últimas 200 movimentações.</p>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/rodape.php'; ?>
